# importing the module
import cv2
import xlsxwriter

startx = None
starty = None
endx = None
endy = None
# function to display the coordinates of
# of the points clicked on the image

file1 = open("AirParamountTempateVid2.txt","a")


def click_event(event, x, y, flags, params):
    # checking for left mouse clicks
    if event == cv2.EVENT_LBUTTONDOWN:
        global startx, starty
        # displaying the coordinates
        # on the Shell
        startx = int(x)
        starty = int(y)
        print(x, ' ', y)

        # displaying the coordinates
        # on the image window
        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(img, str(x) + ',' +
                    str(y), (x, y), font,
                    1, (255, 0, 0), 2)

    # checking for right mouse clicks
    if event == cv2.EVENT_RBUTTONUP:
        # displaying the coordinates
        global endx, endy
        # on the Shell
        endx = int(x)
        endy = int(y)
        print(x, ' ', y)

        # displaying the coordinates
        # on the image window
        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(img, str(x) + ',' +
                    str(y), (x, y), font,
                    1, (255, 0, 0), 2)
        # [rows, columns]
        try:
            crop = img[starty:endy, startx:endx]
        except:
            print("This was not a valid selection. Please remember to go from top-left ot bottom-right.")
            cv2.setMouseCallback('image', click_event)
        # file = open("recognized.txt", "a")
        cv2.imshow('image', crop)
        decision = input("Is this cropped image what you wanted? [y/n]")
        if decision == 'y' or 'Y':
            title = input("Please input the title of the sectioned area.")
            file1.write(title+',')
            file1.write(str(starty)+','+str(endy)+','+str(startx)+','+str(endx)+'\n')
        elif decision == 'n' or 'N':
            cv2.setMouseCallback('image', click_event)
        else:
            print("This was invalid input.")
        cv2.destroyAllWindows()

        cv2.waitKey(0)
        cv2.destroyAllWindows()
# driver function
if __name__ == "__main__":
    # reading the image
    img = cv2.imread(r"C:\Users\grant\PycharmProjects\pythonProject1\TamuHack\img-1.jpeg", 1)

    # displaying the image
    cv2.imshow('image', img)

    # setting mouse handler for the image
    # and calling the click_event() function
    cv2.setMouseCallback('image', click_event)

    # wait for a key to be pressed to exit
    cv2.waitKey(0)
    repeat = input("Would you like to make another section on the invoice? [y/n]")
    if repeat == 'y' or 'Y':
        img = cv2.imread(r"C:\Users\grant\PycharmProjects\pythonProject1\TamuHack\img-1.jpeg", 1)

        # displaying the image
        cv2.imshow('image', img)
        # setting mouse handler for the image
        # and calling the click_event() function
        cv2.setMouseCallback('image', click_event)
    elif repeat == 'n' or 'N':
        print('')# close the window
    cv2.destroyAllWindows()
    file1.close()