import cv2
poppler_path = r"C:\Users\grant\Downloads\Release-23.01.0-0\poppler-23.01.0\Library\bin"
pdf_path = r"C:\Users\grant\PycharmProjects\TamuHack\562-37143.pdf"
from pdf2image import convert_from_path

#This file is used to convert pdf files to jpeg files, which can be more easily manipulated with the library
#OpenCV

pages = convert_from_path(pdf_path=pdf_path, poppler_path = poppler_path)

import os
saving_folder = r"C:\Users\grant\PycharmProjects\pythonProject1\TamuHack"

c=1
for page in pages:
    img_name=f"img-{c}.jpeg"
    page.save(os.path.join(saving_folder, img_name),"JPEG")
    c += 1

