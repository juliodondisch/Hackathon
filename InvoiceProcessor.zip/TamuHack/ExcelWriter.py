import cv2
import pytesseract
pytesseract.pytesseract.tesseract_cmd = r"C:\Users\grant\AppData\Local\Programs\Tesseract-OCR\tesseract"
import xlsxwriter

# Read Input Image


# Check the type of read image
workbook = xlsxwriter.Workbook('AltAirParamount.xlsx')
worksheet = workbook.add_worksheet()

title = None
y1 = None
y2 = None
x1 = None
x2 = None

file1 = open("AirParamountTempate.txt","r")
lines = file1.readlines()
linenum = 1
for line in lines:
    if line[-1] == '\n':
        line = line[:-1]
    b = line.split(',')
    title = b[0]
    y1 = b[1]
    y2 = b[2]
    x1 = b[3]
    x2 = b[4]
    img = cv2.imread(r"C:\Users\grant\PycharmProjects\pythonProject1\TamuHack\img-1.jpeg")
    crop = img[int(y1):int(y2), int(x1):int(x2)]
    cv2.imshow('image',crop)
    text = (pytesseract.image_to_string(crop))
    cv2.waitKey(0)
    worksheet.write('A'+str(linenum), title)
    worksheet.write('B'+str(linenum), text)
    linenum+=1

workbook.close()