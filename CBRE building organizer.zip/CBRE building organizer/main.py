import random as rd
import pandas as pd

teamData = pd.read_csv("team_data.csv")
buildingData = pd.read_csv("building_data.csv")

teams = list(teamData["Strength"])
for i, j in enumerate(teams):
  teams[i] = j - 1
floors = list(buildingData["Мах Capacity"])
for i, j in enumerate(floors):
  floors[i] = j - 1
prefs = list(teamData["No way"])
for i, j in enumerate(prefs):
  prefs[i] = j.strip().split(",")
  for k, n in enumerate(prefs[i]):
    prefs[i][k] = int(n) - 1
tolerate_prefs = list(teamData["Tolerated"])
for i, j in enumerate(tolerate_prefs):
  tolerate_prefs[i] = j.strip().split(",")
  for k, n in enumerate(tolerate_prefs[i]):
    tolerate_prefs[i][k] = int(n) - 1
rounds = [5]


def getCount(assignment):
  count = 0
  for team, floor in enumerate(assignment):
    if floor >= 0:
      count += teams[team]
  return count


def getToleranceScore(assignment):
  toleranceScore = 0
  for team, floor in enumerate(assignment):
    toleranceScore += len([
      x for x in range(len(teams))
      if assignment[x] == floor and floor != -1 and (
        x in prefs[team] or team in prefs[x])
    ])
  multiplier = (11 - (toleranceScore / 2)) / len(teams)
  return -multiplier * getCount(assignment)


def breed(assignmentOne, assignmentTwo):
  assignment = []
  for i in range(len(assignmentOne)):
    randomNum = rd.randint(0, 1)
    if randomNum > 0.5:
      assignment.append(assignmentTwo[i])
    else:
      assignment.append(assignmentOne[i])
  assignment = keepUnderCapacity(assignment)
  return assignment


def shuffle(assignmentQueue, generationSize, iterations):
  for i in range(iterations):
    assignment = assignTeams()
    toleranceScore = getToleranceScore(assignment)
    assignmentQueue.append([assignment, toleranceScore])
  assignmentQueue.sort(key=lambda x: x[1])


def generations(assignmentQueue, generationSize, iterations):
  for i in range(generationSize):
    for j in range(generationSize):
      newAssignment = assignTeams(
        breed(assignmentQueue[i][0], assignmentQueue[j][0]))
      toleranceScore = getToleranceScore(newAssignment)
      assignmentQueue.append([newAssignment, toleranceScore])
  shuffle(assignmentQueue, generationSize, iterations)
  rounds[0] -= 1
  if rounds[0]:
    return True
  generations(assignmentQueue, generationSize)


def keepUnderCapacity(assignment):
  floor_capacity = [0] * len(floors)
  for i, floor in enumerate(assignment):
    if floor >= 0:
      floor_capacity[floor] += teams[i]
  for i, floor_cap in enumerate(floor_capacity):
    if floor_cap > floors[i]:
      team_indexes = [
        index for index, team_floor in enumerate(assignment) if team_floor == i
      ]
      rd.shuffle(team_indexes)
      for team_index in team_indexes:
        for j, floor_cap in enumerate(floor_capacity):
          if floor_cap + teams[team_index] <= floors[j]:
            floor_capacity[j] += teams[team_index]
            floor_capacity[i] -= teams[team_index]
            assignment[team_index] = j
            break
  return assignment


def assignTeams(assignment=[0 for i in range(len(teams))]):
  assignment = keepUnderCapacity(assignment)
  floor_capacity = [0] * len(floors)
  total_capacity = 0
  team_assignment = [-1] * len(teams)
  n = len(teams)
  indices = list(range(n))
  rd.shuffle(indices)
  for i in indices:
    for j, floor in enumerate(floors):
      conflicts = [
        x for x in range(len(teams))
        if team_assignment[x] == j and (x in prefs[i] or i in prefs[x])
      ]
      if len(conflicts) == 0 and floor_capacity[j] + teams[i] <= floor:
        floor_capacity[j] += teams[i]
        total_capacity += teams[i]
        team_assignment[i] = j
        break

  return team_assignment


assignmentQueue = []
generationSize = 50
iterations = 100

for i in range(generationSize):
  assignment = assignTeams()
  assignmentQueue.append([assignment, getToleranceScore(assignment)])

generations(assignmentQueue, generationSize, iterations)
bestArrangement = assignmentQueue[0][0]

print("Total capacity:", getCount(bestArrangement))
for i, team in enumerate(teams):
  print("Team", i + 1, "of size", team, "assigned to floor",
        bestArrangement[i] + 1)
